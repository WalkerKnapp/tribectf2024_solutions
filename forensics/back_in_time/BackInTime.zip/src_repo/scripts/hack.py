# Simple python script to simulate data extraction
import hashlib


def find_key(data):
    return hashlib.sha256(data.encode()).hexdigest()


with open('../secrets/secret_note.txt', 'r') as file:
    content = file.read()
    print(f"Extracted key: {find_key(content)}")
