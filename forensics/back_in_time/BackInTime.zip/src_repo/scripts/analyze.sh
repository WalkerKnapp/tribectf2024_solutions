#!/bin/bash
# Analyze the blueprint history for hidden information
grep -r "hidden key" ../history/
