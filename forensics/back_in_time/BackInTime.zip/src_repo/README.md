# Integrated Science Center 4 (ISC4) at William & Mary

Welcome to the ISC4 repository, which contains files and documents related to the newest addition to William & Mary's Integrated Science Center (ISC) complex. ISC4 is the cutting-edge home for scientific discovery and innovation, supporting a wide range of disciplines, including Chemistry, Biology, Physics, Data Science, and Engineering.

The ISC4 building stands as a testament to William & Mary's commitment to research excellence and the advancement of science and technology. Equipped with state-of-the-art laboratories, advanced computing facilities, and collaborative spaces, ISC4 fosters an environment where students and researchers can tackle some of the most pressing challenges of the modern world.

## Key Features of ISC4:
- **Building Height:** 6 stories
- **Laboratories:** Chemistry, Biology, Physics, Data Science, Engineering
- **Special Facilities:** Quantum Computing Lab, Automated Lab Systems, Rooftop Observatory
- **Collaborative Spaces:** Open-layout design to encourage cross-disciplinary collaboration
- **Sustainability:** LEED-certified with energy-efficient systems and eco-friendly materials

ISC4 continues the legacy of William & Mary's ISC complex, designed to inspire the next generation of scientists and innovators. From advanced research facilities to modern classrooms, the building offers resources for both learning and groundbreaking research.

## Repository Contents:
- **Blueprints:** Files documenting the design evolution of ISC4.
- **Scripts:** Utility scripts related to building operations and lab automation.
- **Configuration Files:** System configuration settings for the building's advanced lab facilities.

Stay tuned for further updates as ISC4 continues to evolve into one of the most advanced academic research centers in the country!
